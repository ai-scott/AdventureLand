declare const runtime: IRuntime;

// Declare globals so they are visible to main.ts
class EnemyAI {
  sprite: ISpriteInstance;
  base: any;
  state: string = "idle";
  timer: number = 0;

  constructor(base: any) {
    this.base = base;
    this.sprite = base;
  }

  setState(state: string, duration: number) {
    this.state = state;
    this.timer = duration * 1000;
  }

  setAnimation(name: string) {
    runtime.callFunction("Set_Animation", [this.base.uid, name] as unknown as CallFunctionParameter);
  }

  simulateMove(direction: string) {
    runtime.callFunction("Simulate_Move", [this.base.uid, direction] as unknown as CallFunctionParameter);
  }

  update(delta: number, player: ISpriteInstance): void {}
  onHurt(damage: number): void {}
}

class CrabbyAI extends EnemyAI {
  direction: string = "Down";

  constructor(base: any) {
    super(base);
  }

  update(delta: number, player: ISpriteInstance) {
    this.timer -= delta;

    if (this.state === "idle" && this.timer <= 0) {
      this.setState("walk", 0.5 + Math.random() * 0.5);
    }

    if (this.state === "walk") {
      this.setAnimation("Walk_" + this.direction);
      this.simulateMove(this.direction.toLowerCase());
      if (this.timer <= 0) {
        this.setState("idle", 0.2 + Math.random() * 0.5);
      }
    }
  }
}

class OozeAI extends EnemyAI {
  direction: string = "Down";

  constructor(base: any) {
    super(base);
  }

  update(delta: number, player: ISpriteInstance) {
    this.timer -= delta;

    if (this.state === "idle" && this.timer <= 0) {
      this.setState("bounce", 0.5);
    }

    if (this.state === "bounce") {
      this.setAnimation("Hop_" + this.direction);
      this.simulateMove(this.direction.toLowerCase());
      if (this.timer <= 0) {
        this.setState("idle", 0.5 + Math.random() * 0.5);
      }
    }
  }
}

// Types using typeof globalThis fallback pattern
type EnemyAIType = typeof EnemyAI.prototype;
type CrabbyAIType = typeof CrabbyAI.prototype;
type OozeAIType = typeof OozeAI.prototype;

const enemies: EnemyAIType[] = [];
let initialized = false;

runtime.addEventListener("tick", () => {
  const delta = runtime.dt * 1000;
  const player = runtime.objects.Player_Base.getFirstInstance();
  if (!player) return;

  if (!initialized) {
    for (const inst of runtime.objects.En_Crab_Base.instances()) {
      enemies.push(new CrabbyAI(inst));
    }

    for (const inst of runtime.objects.En_Ooze_Base.instances()) {
      enemies.push(new OozeAI(inst));
    }

    initialized = true;
  }

  for (const enemy of enemies) {
    enemy.update(delta, player);
  }
});