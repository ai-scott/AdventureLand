declare class IConstructProjectLocalVariables_358912457971062 {
}

declare class IConstructProjectLocalVariables_750142143294285 {
}

declare class IConstructProjectLocalVariables_404032432842984 {
	trigger: string;
}

declare class IConstructProjectLocalVariables_731985286287552 {
	trigger: string;
}

declare class IConstructProjectLocalVariables_603527654786276 {
	trigger: string;
}

declare class IConstructProjectLocalVariables_873523268184196 {
	dialogueIndex: number;
}

declare class IConstructProjectLocalVariables_209776857949973 {
	dialogueIndex: number;
}

declare class IConstructProjectLocalVariables_131049206824953 {
	dialogueIndex: number;
}

declare class IConstructProjectLocalVariables_230385604159820 {
}

declare class IConstructProjectLocalVariables_201333654183452 {
}

declare class IConstructProjectLocalVariables_315297679417563 {
}

declare class IConstructProjectLocalVariables_602907833143051 {
}

declare class IConstructProjectLocalVariables_571912281925696 {
}