export interface EnemyInstance extends ISpriteInstance {
  instVars: {
    [key: string]: any;
  };
}
